#!/usr/bin/env python3

import rospy
import actionlib
from math import atan2
from geometry_msgs.msg import Twist
from trajectory_msgs.msg import JointTrajectory
from trajectory_msgs.msg import JointTrajectoryPoint
from control_msgs.msg import FollowJointTrajectoryAction, FollowJointTrajectoryGoal

class Controller:

    def __init__(self):
        rospy.init_node("twist_to_gear_fork_drive_controls")
        
        self.linear_vel = 0.0
        self.angular_vel = 0.0
        self.wheel_base = 1.0  # Assume a default value for the wheel base, adjust as needed

        rospy.Subscriber('cmd_vel', Twist, self.cmd_callback)

        rospy.loginfo("Waiting for joint trajectory action server...")
        self.action_client = actionlib.SimpleActionClient('/gearfork_bot/controller/follow_joint_trajectory', FollowJointTrajectoryAction)
        self.action_client.wait_for_server()
        self.joint_name = 'motor_joint'
        rospy.loginfo("Connected to joint trajectory action server")

    def cmd_callback(self, msg):
        joint_traj = JointTrajectory()
        joint_traj.joint_names = ['motor_joint']

        # Calculate the steering angle from the angular velocity
        if msg.angular.z != 0 and msg.linear.x != 0:
            steering_angle = atan2(self.wheel_base * msg.angular.z, msg.linear.x)
        
        else:
            steering_angle = 0

        # Create a JointTrajectoryPoint
        point = JointTrajectoryPoint()
        point.positions = [steering_angle]
        point.velocities = [msg.angular.z]
        point.time_from_start = rospy.Duration(0.1)

        # Add the point to the joint trajectory
        joint_traj.points.append(point)

        # Create and send a FollowJointTrajectoryGoal
        goal = FollowJointTrajectoryGoal()
        goal.trajectory = joint_traj

        self.action_client.send_goal(goal)
        rospy.loginfo("Sent joint trajectory goal")

def main():
    controller = Controller()
    rospy.spin()

if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException as e:
        rospy.logwarn(f"Shutting down: {e}")
